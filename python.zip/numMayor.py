#codigo para identificar el numero mayor de una lista

print("identificar el numerpo mas alto de una lista dada")

lista = [-10,-1,0,-12,-13,-5,-17,-33,-87,-99]

nummay = max(misNums)

print(f"Mi lista de numeros es: {misNums}")
print(f"El numero mayor en mi lista es : {nummay}")

