#Codigo para pedir 2 numeros, sumarlos y mostrarlos


num1 = int(input("ingresa el primer numero: "))
num2 = int(input("ingresa el segundo numero: "))
                                                     
totSuma = num1 + num2

print(f"Los numeros capturados son {num1} y {num2} y la suma de ambos es {totSuma}")
